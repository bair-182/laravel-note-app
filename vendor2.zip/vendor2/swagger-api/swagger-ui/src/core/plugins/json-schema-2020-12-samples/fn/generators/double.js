/**
 * @prettier
 */
const doubleGenerator = () => 0.1

export default doubleGenerator
